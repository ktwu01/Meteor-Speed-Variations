



%% calculate: find +- 7 days around those specific days

% id_se : inds for spring equinox March 20, 2022, 11:33 PM, Mar 13-27
% id_ss : inds for summer solstice June 21, 2022, 5:13 PM, Jun 14-28
% id_ae : inds for autumn equinox September 23, 2022, 9:04 AM, Sep 16-30
% id_ws : inds for winter solstice December 22, 2022, 5:47 AM, Dec 15-29
% id_pr : inds for Perihelion Jan-4-2022 R_earthandsun= 147105052 km
% id_ap : inds for Aphelion July-4-2022 R_earthandsun= 152098455 km
if(1)
id_pr = find(mcest>24*(datenum(2022,01,04)- datenum(2014,01,01)-7) ...
    & mcest<24*(datenum(2022,01,04)- datenum(2014,01,01)+7));

id_se = find(mcest>24*(datenum(2022,03,20)- datenum(2014,01,01)-7) ...
    & mcest<24*(datenum(2022,03,20)- datenum(2014,01,01)+7));
    
id_ap = find(mcest>24*(datenum(2022,07,04)- datenum(2014,01,01)-7) ...
    & mcest<24*(datenum(2022,07,04)- datenum(2014,01,01)+7));

id_ss = find(mcest>24*(datenum(2022,07,21)- datenum(2014,01,01)-7) ...
    & mcest<24*(datenum(2022,07,21)- datenum(2014,01,01)+7));

id_ae = find(mcest>24*(datenum(2022,09,23)- datenum(2014,01,01)-7) ...
    & mcest<24*(datenum(2022,09,23)- datenum(2014,01,01)+7));

id_ws = find(mcest>24*(datenum(2022,12,22)- datenum(2014,01,01)-7) ...
    & mcest<24*(datenum(2022,12,22)- datenum(2014,01,01)+7));

save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\ids2014_2022.mat'], ...
    'id_se','id_ss','id_ae','id_ws','id_pr','id_ap' ...
    );

end