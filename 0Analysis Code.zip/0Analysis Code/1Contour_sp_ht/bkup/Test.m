






load(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\OptionalMMRdata2014_2022.mat'], ...
    'number');

rows= 2; cols = 3;
figure; n = 1;
    for dt=169:174 %date of year
        for years = 2014:2022
        dts(years-2013) = datenum(years, 01, 01) - datenum(2014, 01, 01)+1+dt;
        end
	subplot(rows,cols,dt-min(dt)+1);
    hold on; plot(number(dts)); title(['doy=' num2str(dt)])
    end

