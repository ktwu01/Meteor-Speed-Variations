% load original data
clear all;clc;close all;
addpath 'D:\000Learning\00Research\00DataAndCode\Mengcheng_wkt_Nhindley\Functions'

% Mention! BEFORE YOU RUN THIS CODE
% please turn on ALL or SOME of the if (1) so that you can satisfile your needs!
% try not to just directely run this 

%% Goal 0 for goal 1 & 3
% get an imaginary year whose each day consists of 9 days from 9yrs
% construct imgyr
% { speed,
%   height
% };
%     imgyr.sp=[];
%     imgyr.ht=[];
% for years= 2014:2022
%     for i=1:365
%     imgyr.sp(i)=imgyr.sp(i)
% 
%     end
% end
% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Speed contourf of each day of 9 years
% time use: about 7 mins*3287/108
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
load('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\OptionalMMRdata2014_2022.mat');
    n=1;
mcspdis9yrs = zeros(41,3288);
for sp=0:2000:80000
    m=1;
    for dt=0:3287 %date
%     for dt=0:3287 %date
        mcspdis9yrs(n,m)=length(find(mcest>24*(dt-1) & mcest<=24*(dt) ...
            & speed>sp-1000 & speed<sp+1000));
        m=m+1;
    end
    n=n+1;
end

disp('Caculated: speed contourf data of each day of 9 years');

% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdis9yrs_2014_2022.mat'], ...
    'mcspdis9yrs');
disp('Saved: speed contourf data of each day of 9 years');
figure;contourf(mcspdis9yrs);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% height contourf of each day of 9 years
% time use: about 7 mins*3287/108
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
load('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\OptionalMMRdata2014_2022.mat');
    n=1;
mchdis9yrs = zeros(41,3288);
for ht=70:110
    m=1;
    for dt=0:3287 %date
%     for dt=0:3287 %date
        mchdis9yrs(n,m)=length(find(mcest>24*(dt-1) & mcest<=24*(dt) ...
            & mch>ht-0.5 & mch<ht+0.5));
        m=m+1;
    end
    n=n+1;
end

disp('Caculated: height contourf data of each day of 9 years');

% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mchdis9yrs_2014_2022.mat'], ...
    'mchdis9yrs');

figure;contourf(mchdis9yrs);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% height contourf of ave year
% time use: about 20 mins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
load('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\OptionalMMRdata2014_2022.mat');
mchdisave = zeros(41,366);
n=1;
for ht=70:110
    m=1;
    for dt=1:366 %date
        mchdisave(n,m)=length(find(doy>dt-0.5 & doy<dt+0.5 ...
            & mch>ht-0.5 & mch<ht+0.5));
        % DO NOT use: find (doy = dt)
        m=m+1;
    end
    n=n+1;
end

disp('Calcued: height contourf data of ave year');
% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mchdisave_2014_2022.mat'], ...
    'mchdisave');

figure;contourf(mchdisave);
disp('Saved: height contourf data of ave year');

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% speed contourf of ave year: directly sum for dis of 9yrs
% time use: about 20 mins?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(1)
load(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdis9yrs_2014_2022.mat'], ...
    'mcspdis9yrs');
mcspdisave = zeros(41,366);

for spinds=1:1:41
    for dt=1:365 %date
        for years = 2014:2022
%         i = datenum(years, 01, 01) - datenum(2014, 01, 01)+1;
%         j = datenum(years, 12, 31) - datenum(2014, 01, 01)+1;
        dts = datenum(years, 01, 01) - datenum(2014, 01, 01)+1+dt;
        mcspdisave(spinds,dt) = sum(mcspdis9yrs(spinds,dts));
        end
    end
end

disp('Calcued: speed contourf data of ave year');
% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdisave_2014_2022_mtd2.mat'], ...
    'mcspdisave');

figure;contourf(mcspdisave);
disp('Saved: speed contourf data of ave year');

end

% %% all finally save
% save('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\MMRalldis_2014_2022.mat');
% disp('All successfully saved!');
