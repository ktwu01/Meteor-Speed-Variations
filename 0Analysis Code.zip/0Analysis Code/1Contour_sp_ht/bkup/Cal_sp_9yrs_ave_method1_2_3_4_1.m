



% load original data
clear all;clc;close all;
addpath 'D:\000Learning\00Research\00DataAndCode\Mengcheng_wkt_Nhindley\Functions'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Speed contourf of each day of 9 years
% time use: about 7 mins*3287/108
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
    n=1;
mcspdis9yrs = zeros(41,3288);
for sp=0:2000:80000
    m=1;
    for dt=0:3287 %date
%     for dt=0:3287 %date
        mcspdis9yrs(n,m)=length(find(mcest>24*(dt-1) & mcest<=24*(dt) ...
            & speed>sp-1000 & speed<sp+1000));
        m=m+1;
    end
    n=n+1;
end

disp('Caculated: speed contourf data of each day of 9 years');

% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdis9yrs_2014_2022.mat'], ...
    'mcspdis9yrs');
disp('Saved: speed contourf data of each day of 9 years');
figure;contourf(mcspdis9yrs);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% speed contourf of ave year
% time use: about 20 mins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
mcspdisave = zeros(41,366);
speed=speed/1000;
n=1;
for sp=0:2:80
    m=1;
    for dt=1:366 %date
        mcspdisave(n,m)=length(find(doy>dt-0.5 & doy<dt+0.5 ...
            & speed>sp-1 & speed<sp+1));
        % DO NOT use: find (doy = dt)
        m=m+1;
    end
    n=n+1;
end

disp('Calcued: speed contourf data of ave year');
% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdisave_2014_2022.mat'], ...
    'mcspdisave');

figure;contourf(mcspdisave);
disp('Saved: speed contourf data of ave year');

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% speed contourf of ave year: directly sum for dis of 9yrs: merhod 2
% time use: about 0.5 mins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
load(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdis9yrs_2014_2022.mat'], ...
    'mcspdis9yrs');
mcspdisave = zeros(41,366);

for spinds=1:1:41
    for dt=1:365 %date
        for years = 2014:2022
%         i = datenum(years, 01, 01) - datenum(2014, 01, 01)+1;
%         j = datenum(years, 12, 31) - datenum(2014, 01, 01)+1;
        dts = datenum(years, 01, 01) - datenum(2014, 01, 01)+1+dt;
        mcspdisave(spinds,dt) = sum(mcspdis9yrs(spinds,dts));
        end
    end
end

disp('Calcued: speed contourf data of ave year');
% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdisave_2014_2022_mtd2.mat'], ...
    'mcspdisave');

figure;contourf(mcspdisave);
disp('Saved: speed contourf data of ave year');

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% speed contourf of ave year: directly sum for 
% dis of 9yrs: merhod 3
% time use: about 10 secs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
load('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\OptionalMMRdata2014_2022.mat','number');
figure; scatter(1:3287, number);

load(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdis9yrs_2014_2022.mat'], ...
    'mcspdis9yrs');

%% smooth period
SmtPrd = 30

for i = 1:41
%     sm9yrs(i,:) = smoothdata (mcspdis9yrs(i,:),'movmedian',SmtPrd);
    sm9yrs(i,:) = smoothdata (mcspdis9yrs(i,:),'movmean',SmtPrd);
end

mcspdis9yrs = (mcspdis9yrs-sm9yrs)./sm9yrs;

%% omit number <1000
abndt = find(number<1000);
% abndtbf = abndt-1;
% abndtbf = abndtbf(abndtbf~=0);
% mcspdis9yrs(:,abndtbf)=nan;
mcspdis9yrs(:,abndt)=nan;
% mcspdis9yrs(:,abndt+1)=nan;

%% keep the 20-70km/s region
mcspdis9yrs(1:10,:)=nan; % omit 0-20km/s
mcspdis9yrs(37:41,:)=nan; % omit 70-80km/s

%% superposition
mcspdisave = zeros(41,366);
for spinds=1:1:41
    for dt=1:365 %date
        for years = 2014:2022
%         i = datenum(years, 01, 01) - datenum(2014, 01, 01)+1;
%         j = datenum(years, 12, 31) - datenum(2014, 01, 01)+1;
        dts = datenum(years, 01, 01) - datenum(2014, 01, 01)+1+dt;
        mcspdisave(spinds,dt) = median(mcspdis9yrs(spinds,dts),'omitnan');
        end
    end
end

%% omit  <0
mcspdisave(mcspdisave<0) = nan;

disp('Calcued: speed contourf data of ave year');
% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdisave_2014_2022_mtd3.mat'], ...
    'mcspdis9yrs','mcspdisave');

max(max(mcspdis9yrs))
max(max(mcspdisave))

figure;
clen=100; cmap = nph_saturate(cbrew('nph_RainbowWhite',clen),0.7);
hold on; colormap(gca,cmap);
contourf(0:3287,0:2:80,mcspdis9yrs,100,'Linestyle','none');colorbar; 
ylim([20 70])

% clim([0 2])

figure;
clen=100; cmap = nph_saturate(cbrew('nph_RainbowWhite',clen),0.7);
hold on; colormap(gca,cmap);
contourf(0:365,0:2:80,mcspdisave,100,'Linestyle','none');colorbar; 
ylim([20 70])

% clim([0 2])

disp('Saved: speed contourf data of ave year');

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% speed contourf of ave year: method 4
% NOTE: did not subtract the BG
% time use: about 20 mins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(0)
load('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\OptionalMMRdata2014_2022.mat','doy','speed','number','mcest');

mcspdisave = zeros(41,366);
speed=speed/1000;

%% omit number <1000
abndt = find(number<1000);

for i = 1: length(abndt)
	speed(mcest>24*(abndt(i)-0.5) & mcest<24*(abndt(i)+0.5)) = nan;
	doy(mcest>24*(abndt(i)-0.5) & mcest<24*(abndt(i)+0.5)) = nan;
end

%% calculate by doy
n=1;
for sp=0:2:80
    m=1;
    for dt=1:366 %date
        mcspdisave(n,m)=length(find(doy>dt-0.5 & doy<dt+0.5 ...
            & speed>sp-1 & speed<sp+1));
        % DO NOT use: find (doy = dt)
        m=m+1;
    end
    n=n+1;
end

% save file
save(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdisave_2014_2022_mtd4.mat'], ...
    'mcspdisave');
disp('Saved: speed contourf data of ave year');


figure;
clen=100; cmap = nph_saturate(cbrew('nph_RainbowWhite',clen),0.7);
hold on; colormap(gca,cmap);
contourf(0:365,0:2:80,mcspdisave,100,'Linestyle','none');colorbar; 
ylim([20 70])

end


load(['D:\000learning\00research\00DataAndCode\' ...
    'Mengcheng_wkt_Nhindley\mcspdisave_2014_2022_mtd4.mat'], ...
    'mcspdisave');

figure;
clen=100; cmap = nph_saturate(cbrew('nph_Rainbow',clen),1.0);
hold on; colormap(gca,cmap);
contourf(0:365,0:2:80,mcspdisave,100,'Linestyle','none');colorbar; 
ylim([10 70])


hold on; axx=gca;
axx.XTick = datenum(2014,1:12,1)-datenum(2014,01,01);
datetick('x','m','keepticks','keeplimits')

axx.XTickLabel = {};
fs = 12

% months as ticks using text at 15th day
ytix1 = min(gca().YLim)-(max(gca().YLim)-min(gca().YLim))*0.01;
xtixMt = datenum(2014,1:12,15)-datenum(2014,01,01);
for xt = xtixMt
    if inrange(xt,xlim)
        mn = monthname(month(xt),'mmm');
    hold on; text(xt,ytix1,mn,'fontsize',fs,'horizontalalignment','center','VerticalAlignment','top');
    end
end

axx.XMinorTick = 'off';

%% smooth period
SmtPrd = 30

for i = 1:41
    smave(i,:) = smoothdata (mcspdisave(i,:),'movmedian',SmtPrd);
end

mcspdisave = (mcspdisave-smave)./smave;


figure;
clen=100; cmap = nph_saturate(cbrew('nph_RainbowWhite',clen),0.7);
hold on; colormap(gca,cmap);
contourf(0:365,0:2:80,mcspdisave,100,'Linestyle','none');colorbar; 
ylim([20 70])

% % % % % % % %% all finally save
% % % % % % % save('D:\000learning\00research\00DataAndCode\Mengcheng_wkt_Nhindley\MMRalldis_2014_2022.mat');
% % % % % % % disp('All successfully saved!');
